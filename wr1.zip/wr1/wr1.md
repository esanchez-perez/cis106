# Week Report 1

## Slack Screenshot
take a screenshot of slack and place it here
![Slack screenshot](slacks.png)

## Github Screenshot
take a screenshot of your github account and place it here
![GitHub Screenshot](github.png)

## Discussion Board Screenshot
Take a screenshot of your discussion board post and place it here
![Discussion 1](filename.png)

## Acknowledgements
* By submitting this assignment I [Elizabeth Sanchez-Perez] acknowledge that I have read the syllabus or home page of the course
* I also acknowledge that I have written down any questions that I have for the professor and will ask them in class or via Slack 
* I also acknowledge that I am aware that the final exam is In Person
