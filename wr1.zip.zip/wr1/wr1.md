---
name: Elizabeth Sanchez-Perez
assignment: week report 1
course: cis106
semester: Fall 2025
---

Week Report 1 Submission

## Slack Screenshot
take a screenshot of slack and place it here
![Slack screenshot](slacks.png)

## Github Screenshot
take a screenshot of your github account and place it here
![GitHub Screenshot](github.png)

## Acknowledgements
* By submitting this assignment I [Elizabeth Sanchez-Perez] acknowledge that I have read the syllabus or home page of the course
* I also acknowledge that I have written down any questions that I have for the professor and will ask them in class, via Slack or 
* I also acknowledge that I am aware that the final exam is In Person
