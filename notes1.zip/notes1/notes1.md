Elizabeth Sanchez Notes
## What is Markdown? 
**Markdown** is a markup language that lets you write plain text documents with a few lightweight formatting options. 
- **Markdown** was created by John Gruber in 2004
- The file extension for markdown is .md or .markdown
#### What is a markup language?
*Markup language* is text-encoding system which specifies the structure and formatting of a document. 

#### What more can we do with Markdown?
- add formatting to plain text
- convert plain text documents to HTML, PDF, Docx, and Ppx

*Headings* - use # symbol before word - more # = smaller headings 
*Bold Text* - use two * one before the word and after.
*Italics* - use one * before and after a word

## What is Git?
Git is a free, open-source distribution that tracks changes in source code and manages project files over time. 
Works offline and is a local version control software.

## What is Github?
Github is a cloud-based hosting platform online that requires internet connection. Github is a service to host git projects 