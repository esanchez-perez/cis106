Elizabeth Sanchez Notes
## What is Markdown? 

## What is Git?

## What is Github?